!pip install -r requirements.txt

!python main.py --net=vit --cos --batch-size=256 --aug --max-epoch=200

!python main.py --net=vit_small --cos --batch-size=256 --aug --max-epoch=200