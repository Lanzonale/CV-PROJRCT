from .vit import ViT
from .vit_small import ViT as ViT_Small
from .vit_small import SPT
