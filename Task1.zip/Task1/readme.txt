trainstage1.py自监督

trainstage2.py监督学习